class myClass:
    def addPrint(self, a, b):
        print(a + b)

    def print(self, a):
        print(a)

    def printTestText(self):
        print("Test text")